// File: app/src/main/java/com/pinli/app/core/UiEvent.java
package com.pinli.app.core;

public final class UiEvent {
    public final String message;

    public UiEvent(String message) {
        this.message = message;
    }
}
