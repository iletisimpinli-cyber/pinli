// File: app/src/main/java/com/pinli/app/data/model/Chat.java
package com.pinli.app.data.model;

import androidx.annotation.Keep;

@Keep
public class Chat {
    public String id;
    public String uidA;
    public String uidB;
    public String lastMessage;
    public long lastAt;

    public Chat() {}
}
