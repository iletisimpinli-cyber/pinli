// File: app/src/main/java/com/pinli/app/data/repo/BlockRepository.java
package com.pinli.app.data.repo;

import androidx.annotation.NonNull;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.pinli.app.data.FirebaseRefs;
import com.pinli.app.util.Time;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class BlockRepository {
    private final FirebaseFirestore db = FirebaseRefs.db();

    public interface Callback<T> {
        void onSuccess(@NonNull T data);
        void onError(@NonNull String message);
    }

    public void loadBlockedUids(@NonNull String uid, Callback<Set<String>> cb) {
        db.collection(FirebaseRefs.COL_BLOCKS)
                .whereEqualTo("blockerUid", uid)
                .get()
                .addOnSuccessListener(qs -> cb.onSuccess(extract(qs)))
                .addOnFailureListener(e -> cb.onError(e.getMessage() != null ? e.getMessage() : "DB error"));
    }

    private Set<String> extract(QuerySnapshot qs) {
        Set<String> out = new HashSet<>();
        qs.getDocuments().forEach(d -> {
            String blockedUid = d.getString("blockedUid");
            if (blockedUid != null) out.add(blockedUid);
        });
        return out;
    }

    public void block(@NonNull String blockerUid, @NonNull String blockedUid, Callback<Boolean> cb) {
        String id = blockerUid + "_" + blockedUid;
        Map<String, Object> data = new HashMap<>();
        data.put("id", id);
        data.put("blockerUid", blockerUid);
        data.put("blockedUid", blockedUid);
        data.put("createdAt", Time.now());
        db.collection(FirebaseRefs.COL_BLOCKS).document(id)
                .set(data)
                .addOnSuccessListener(v -> cb.onSuccess(true))
                .addOnFailureListener(e -> cb.onError(e.getMessage() != null ? e.getMessage() : "DB error"));
    }

    public void unblock(@NonNull String blockerUid, @NonNull String blockedUid, Callback<Boolean> cb) {
        String id = blockerUid + "_" + blockedUid;
        db.collection(FirebaseRefs.COL_BLOCKS).document(id)
                .delete()
                .addOnSuccessListener(v -> cb.onSuccess(true))
                .addOnFailureListener(e -> cb.onError(e.getMessage() != null ? e.getMessage() : "DB error"));
    }
}
