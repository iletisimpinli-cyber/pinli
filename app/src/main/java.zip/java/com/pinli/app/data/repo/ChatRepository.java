// File: app/src/main/java/com/pinli/app/data/repo/ChatRepository.java
package com.pinli.app.data.repo;

import androidx.annotation.NonNull;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.pinli.app.data.FirebaseRefs;
import com.pinli.app.util.Time;

import java.util.HashMap;
import java.util.Map;

public class ChatRepository {
    private final FirebaseFirestore db = FirebaseRefs.db();

    public interface Callback<T> {
        void onSuccess(@NonNull T data);
        void onError(@NonNull String message);
    }

    public static String chatIdFor(String a, String b) {
        return (a.compareTo(b) < 0) ? (a + "_" + b) : (b + "_" + a);
    }

    public void sendMessageMutualOnly(@NonNull String chatId, @NonNull String uidA, @NonNull String uidB,
                                      @NonNull String fromUid, @NonNull String text, Callback<Boolean> cb) {
        long now = Time.now();
        Map<String, Object> chat = new HashMap<>();
        chat.put("id", chatId);
        chat.put("uidA", uidA);
        chat.put("uidB", uidB);
        chat.put("lastMessage", text);
        chat.put("lastAt", now);

        String msgId = db.collection(FirebaseRefs.COL_CHATS).document(chatId)
                .collection(FirebaseRefs.COL_MESSAGES).document().getId();

        Map<String, Object> msg = new HashMap<>();
        msg.put("id", msgId);
        msg.put("chatId", chatId);
        msg.put("fromUid", fromUid);
        msg.put("text", text);
        msg.put("createdAt", now);

        db.collection(FirebaseRefs.COL_CHATS).document(chatId)
                .set(chat)
                .addOnSuccessListener(v -> db.collection(FirebaseRefs.COL_CHATS).document(chatId)
                        .collection(FirebaseRefs.COL_MESSAGES).document(msgId)
                        .set(msg)
                        .addOnSuccessListener(v2 -> cb.onSuccess(true))
                        .addOnFailureListener(e -> cb.onError(e.getMessage() != null ? e.getMessage() : "DB error")))
                .addOnFailureListener(e -> cb.onError(e.getMessage() != null ? e.getMessage() : "DB error"));
    }

    public Query chatsQuery(@NonNull String uid) {
        return db.collection(FirebaseRefs.COL_CHATS)
                .whereArrayContainsAny("participants", java.util.List.of(uid)); // fallback not used (schema simplified)
    }

    public Query messagesQuery(@NonNull String chatId) {
        return db.collection(FirebaseRefs.COL_CHATS).document(chatId)
                .collection(FirebaseRefs.COL_MESSAGES)
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .limit(200);
    }
}
