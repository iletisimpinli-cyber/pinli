// File: app/src/main/java/com/pinli/app/data/repo/FollowRepository.java
package com.pinli.app.data.repo;

import androidx.annotation.NonNull;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.pinli.app.data.FirebaseRefs;
import com.pinli.app.util.Time;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class FollowRepository {
    private final FirebaseFirestore db = FirebaseRefs.db();

    public interface Callback<T> {
        void onSuccess(@NonNull T data);
        void onError(@NonNull String message);
    }

    private static String followId(String fromUid, String toUid) { return fromUid + "_" + toUid; }

    public void followPublic(@NonNull String fromUid, @NonNull String toUid, Callback<Boolean> cb) {
        String id = followId(fromUid, toUid);
        Map<String, Object> data = new HashMap<>();
        data.put("id", id);
        data.put("fromUid", fromUid);
        data.put("toUid", toUid);
        data.put("createdAt", Time.now());
        db.collection(FirebaseRefs.COL_FOLLOWS).document(id)
                .set(data)
                .addOnSuccessListener(v -> cb.onSuccess(true))
                .addOnFailureListener(e -> cb.onError(e.getMessage() != null ? e.getMessage() : "DB error"));
    }

    public void requestFollowPrivate(@NonNull String fromUid, @NonNull String toUid, Callback<Boolean> cb) {
        String id = followId(fromUid, toUid);
        Map<String, Object> data = new HashMap<>();
        data.put("id", id);
        data.put("fromUid", fromUid);
        data.put("toUid", toUid);
        data.put("status", "pending");
        data.put("createdAt", Time.now());
        db.collection(FirebaseRefs.COL_FOLLOW_REQUESTS).document(id)
                .set(data)
                .addOnSuccessListener(v -> cb.onSuccess(true))
                .addOnFailureListener(e -> cb.onError(e.getMessage() != null ? e.getMessage() : "DB error"));
    }

    public void acceptRequest(@NonNull String fromUid, @NonNull String toUid, Callback<Boolean> cb) {
        String id = followId(fromUid, toUid);
        Map<String, Object> update = new HashMap<>();
        update.put("status", "accepted");
        db.collection(FirebaseRefs.COL_FOLLOW_REQUESTS).document(id)
                .update(update)
                .addOnSuccessListener(v ->
                        followPublic(fromUid, toUid, new Callback<Boolean>() {
                            @Override public void onSuccess(@NonNull Boolean data) { cb.onSuccess(true); }
                            @Override public void onError(@NonNull String message) { cb.onError(message); }
                        })
                )
                .addOnFailureListener(e -> cb.onError(e.getMessage() != null ? e.getMessage() : "DB error"));
    }

    public void loadFollowing(@NonNull String uid, Callback<Set<String>> cb) {
        db.collection(FirebaseRefs.COL_FOLLOWS)
                .whereEqualTo("fromUid", uid)
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .limit(2000)
                .get()
                .addOnSuccessListener(qs -> {
                    Set<String> out = new HashSet<>();
                    qs.getDocuments().forEach(d -> {
                        String to = d.getString("toUid");
                        if (to != null) out.add(to);
                    });
                    cb.onSuccess(out);
                })
                .addOnFailureListener(e -> cb.onError(e.getMessage() != null ? e.getMessage() : "DB error"));
    }

    public void loadFollowers(@NonNull String uid, Callback<Set<String>> cb) {
        db.collection(FirebaseRefs.COL_FOLLOWS)
                .whereEqualTo("toUid", uid)
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .limit(2000)
                .get()
                .addOnSuccessListener(qs -> {
                    Set<String> out = new HashSet<>();
                    qs.getDocuments().forEach(d -> {
                        String from = d.getString("fromUid");
                        if (from != null) out.add(from);
                    });
                    cb.onSuccess(out);
                })
                .addOnFailureListener(e -> cb.onError(e.getMessage() != null ? e.getMessage() : "DB error"));
    }

    public static boolean isMutual(Set<String> following, Set<String> followers, String otherUid) {
        return following != null && followers != null && following.contains(otherUid) && followers.contains(otherUid);
    }
}
