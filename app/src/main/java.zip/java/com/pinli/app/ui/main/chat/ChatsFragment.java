// File: app/src/main/java/com/pinli/app/ui/main/chat/ChatsFragment.java
package com.pinli.app.ui.main.chat;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.pinli.app.databinding.FragmentChatsBinding;

public class ChatsFragment extends Fragment {

    private FragmentChatsBinding vb;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        vb = FragmentChatsBinding.inflate(inflater, container, false);
        return vb.getRoot();
    }

    @Override
    public void onDestroyView() {
        vb = null;
        super.onDestroyView();
    }
}
