// File: app/src/main/java/com/pinli/app/ui/main/chat/ChatsViewModel.java
package com.pinli.app.ui.main.chat;

import androidx.lifecycle.ViewModel;

public class ChatsViewModel extends ViewModel {
    // MVP: Chat list UI stub (no pseudo, but simple empty screen behavior)
}
