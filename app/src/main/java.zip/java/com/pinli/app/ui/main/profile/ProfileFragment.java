// File: app/src/main/java/com/pinli/app/ui/main/profile/ProfileFragment.java
package com.pinli.app.ui.main.profile;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.pinli.app.R;
import com.pinli.app.databinding.FragmentProfileBinding;
import com.pinli.app.ui.auth.LoginActivity;

public class ProfileFragment extends Fragment {

    private FragmentProfileBinding vb;
    private ProfileViewModel vm;
    private boolean ignoreSwitch = false;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        vb = FragmentProfileBinding.inflate(inflater, container, false);
        return vb.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        vm = new ViewModelProvider(this).get(ProfileViewModel.class);

        vm.start();

        vm.loading().observe(getViewLifecycleOwner(), l ->
                vb.progress.setVisibility(Boolean.TRUE.equals(l) ? View.VISIBLE : View.GONE)
        );

        vm.toast().observe(getViewLifecycleOwner(), e -> {
            if (getActivity() != null) {
                android.widget.Toast.makeText(getActivity(), e.message, android.widget.Toast.LENGTH_LONG).show();
            }
        });

        vm.signedOut().observe(getViewLifecycleOwner(), out -> {
            if (Boolean.TRUE.equals(out) && getActivity() != null) {
                Intent i = new Intent(getActivity(), LoginActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                getActivity().finish();
            }
        });

        vm.myLocation().observe(getViewLifecycleOwner(), ul -> {
            // Set initial state without triggering listener.
            ignoreSwitch = true;
            vb.switchHide24h.setChecked(ul != null && ul.isHidden);
            ignoreSwitch = false;

            boolean enabled = ul != null && ul.geohash != null && !ul.geohash.isEmpty();
            vb.switchHide24h.setEnabled(enabled);

            if (vb.tvHideInfo != null) {
                vb.tvHideInfo.setText(buildHideInfo(ul));
            }
        });

        vb.switchHide24h.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (ignoreSwitch) return;
            if (!buttonView.isEnabled()) {
                ignoreSwitch = true;
                vb.switchHide24h.setChecked(false);
                ignoreSwitch = false;
                android.widget.Toast.makeText(requireContext(), getString(R.string.err_set_location_first), android.widget.Toast.LENGTH_LONG).show();
                return;
            }

            if (isChecked) {
                new MaterialAlertDialogBuilder(requireContext())
                        .setTitle(R.string.hide_confirm_title)
                        .setMessage(R.string.hide_confirm_message)
                        .setNegativeButton(R.string.cancel, (d, w) -> {
                            d.dismiss();
                            ignoreSwitch = true;
                            vb.switchHide24h.setChecked(false);
                            ignoreSwitch = false;
                        })
                        .setPositiveButton(R.string.ok, (d, w) -> vm.toggleHidden24h(true))
                        .show();
            } else {
                vm.toggleHidden24h(false);
            }
        });
        vb.btnSignOut.setOnClickListener(v -> vm.signOut());
    }

    private String buildHideInfo(@Nullable com.pinli.app.data.model.UserLocation ul) {
        if (ul == null || ul.geohash == null || ul.geohash.isEmpty()) {
            return getString(R.string.hide_info_no_location);
        }
        if (ul.isHidden) {
            long now = System.currentTimeMillis();
            long left = Math.max(0L, ul.hiddenUntil - now);
            return getString(R.string.hide_info_hidden, formatRemaining(left));
        }
        return getString(R.string.hide_info_visible);
    }

    private String formatRemaining(long millis) {
        long totalMinutes = Math.max(0L, millis / 60000L);
        long hours = totalMinutes / 60L;
        long minutes = totalMinutes % 60L;
        if (hours <= 0) return minutes + "m";
        return hours + "h " + minutes + "m";
    }

    @Override
    public void onDestroyView() {
        vb = null;
        super.onDestroyView();
    }
}
